# register-mcp

Stateless Node.js MCP server for controlled company-register lookups.

## Current tool

`belgium_register({ company_register_id })`

The tool accepts exactly one argument, validates the Belgian company number, calls CBEAPI, and returns only a whitelisted subset of registry data. The application has no database, cache, or persistence layer and does not log request or company payloads.

Returned fields:

- country / register
- company register ID (raw + formatted)
- denomination
- status
- legal form / legal situation when supplied by CBEAPI
- registered address
- website
- up to 10 NACE activities
- source

## Repository structure

```text
src/
  providers/          country-specific upstream adapters
  tools/              MCP tool definitions
  config.ts
  server.ts
  index.ts
Dockerfile
compose.yaml
.env.example
```

A future `french_register` should be implemented as `src/providers/france.ts` + `src/tools/french-register.ts` and registered in `src/server.ts`.

## Security posture

- Static 32-byte MCP bearer secret (64 hex characters)
- Constant-time bearer-secret comparison
- No application persistence
- MCP request body capped at 16 KiB
- Optional Host allowlist
- Browser-style Origin requests rejected by default
- Container runs as the non-root `node` user
- All Linux capabilities dropped
- `no-new-privileges`
- read-only container filesystem
- bounded PID / memory / CPU resources
- port published only to `127.0.0.1:3000` on the host

Do not expose container port 3000 directly to the Internet. Put an HTTPS reverse proxy in front of it when external access is required.

## First deployment on Ubuntu

Clone the repository:

```bash
cd /opt
sudo git clone <YOUR_GITHUB_REPO_URL> register-mcp
sudo chown -R bene:bene /opt/register-mcp
cd /opt/register-mcp
```

Create the runtime environment file:

```bash
cp .env.example .env
chmod 600 .env
nano .env
```

Generate the MCP bearer secret on the server:

```bash
openssl rand -hex 32
```

Set `CBE_API_KEY` and `MCP_API_KEY` in `.env`.

Build and start:

```bash
sudo docker compose build --pull
sudo docker compose up -d
```

Check status:

```bash
sudo docker compose ps
sudo docker compose logs --tail=100 register-mcp
curl http://127.0.0.1:3000/health
```

The health response should be:

```json
{"ok":true}
```

## MCP test

Load the secret without printing it:

```bash
set -a
. ./.env
set +a
```

List tools:

```bash
curl -sS -X POST http://127.0.0.1:3000/mcp \
  -H "Authorization: Bearer $MCP_API_KEY" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}'
```

Call Belgium lookup:

```bash
curl -sS -X POST http://127.0.0.1:3000/mcp \
  -H "Authorization: Bearer $MCP_API_KEY" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"belgium_register","arguments":{"company_register_id":"0783225609"}}}'
```

## Updating production

```bash
cd /opt/register-mcp
git pull --ff-only
sudo docker compose build --pull
sudo docker compose up -d
sudo docker image prune -f
```

`.env` is intentionally ignored by Git and remains on the server across pulls.

## Later: HTTPS

When `register-mcp.maguar.com` is introduced, keep Docker bound to `127.0.0.1:3000` and proxy only `/mcp` from Caddy/Nginx over HTTPS. Add the public host to `ALLOWED_HOSTS`.
