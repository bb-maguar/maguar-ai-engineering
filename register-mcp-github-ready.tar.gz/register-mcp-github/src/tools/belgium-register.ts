import { McpServer } from '@modelcontextprotocol/server';
import * as z from 'zod/v4';
import { BelgiumRegisterProvider } from '../providers/belgium.js';

const addressSchema = z.object({
  street: z.string().nullable(),
  street_number: z.string().nullable(),
  postal_code: z.string().nullable(),
  city: z.string().nullable(),
  country_code: z.string().nullable()
}).nullable();

const outputSchema = z.object({
  country: z.string(),
  register: z.string(),
  company_register_id: z.string(),
  company_register_id_formatted: z.string().nullable(),
  name: z.string().nullable(),
  status: z.string().nullable(),
  legal_form: z.string().nullable(),
  legal_situation: z.string().nullable(),
  registered_address: addressSchema,
  website: z.string().nullable(),
  activities: z.array(z.object({
    code: z.string(),
    description: z.string().nullable(),
    classification: z.string().nullable()
  })),
  source: z.string()
});

export function registerBelgiumRegisterTool(server: McpServer): void {
  const provider = new BelgiumRegisterProvider();

  server.registerTool(
    'belgium_register',
    {
      title: 'Belgian Company Register',
      description: 'Look up one Belgian company in the CBE/KBO/BCE by company register ID. Accepts only the company register ID and returns a limited, structured set of official registry data.',
      inputSchema: z.object({
        company_register_id: z.string().min(1).describe('Belgian CBE/KBO/BCE company number, e.g. 0783225609 or 0783.225.609')
      }).strict(),
      outputSchema,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true
      }
    },
    async ({ company_register_id }) => {
      try {
        const result = await provider.lookup(company_register_id);
        return {
          content: [{ type: 'text', text: JSON.stringify(result) }],
          structuredContent: result
        };
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Unknown register lookup error.';
        return {
          isError: true,
          content: [{ type: 'text', text: message }]
        };
      }
    }
  );
}
