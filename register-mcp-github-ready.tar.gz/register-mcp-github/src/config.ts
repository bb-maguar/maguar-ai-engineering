function required(name: string): string {
  const value = process.env[name]?.trim();
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

function csv(name: string): string[] {
  return (process.env[name] ?? '')
    .split(',')
    .map(value => value.trim().toLowerCase())
    .filter(Boolean);
}

const mcpApiKey = required('MCP_API_KEY');

if (!/^[a-f0-9]{64}$/i.test(mcpApiKey)) {
  throw new Error('MCP_API_KEY must be exactly 32 random bytes represented as 64 hexadecimal characters.');
}

const port = Number(process.env.PORT || '3000');
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error('PORT must be an integer between 1 and 65535');
}

export const config = {
  cbeApiKey: required('CBE_API_KEY'),
  mcpApiKey,
  host: process.env.HOST?.trim() || '0.0.0.0',
  port,
  allowedHosts: csv('ALLOWED_HOSTS'),
  allowedOrigins: csv('ALLOWED_ORIGINS'),
  cbeBaseUrl: 'https://cbeapi.be/api'
};
