import { createMcpHandler, McpServer } from '@modelcontextprotocol/server';
import { registerBelgiumRegisterTool } from './tools/belgium-register.js';

export function buildServer(): McpServer {
  const server = new McpServer({
    name: 'register-mcp',
    version: '0.1.0'
  });

  registerBelgiumRegisterTool(server);

  // Future country tools belong here, e.g. registerFrenchRegisterTool(server).
  return server;
}

export const mcpHandler = createMcpHandler(buildServer, {
  // The server only accepts tiny structured lookup requests.
  maxRequestBodySize: 16 * 1024,
  onerror: error => {
    // Never log request bodies, company data, or secrets.
    console.error(`[mcp] ${error.name}: ${error.message}`);
  }
});
