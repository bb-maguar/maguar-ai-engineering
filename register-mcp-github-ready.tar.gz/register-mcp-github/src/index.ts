import { timingSafeEqual } from 'node:crypto';
import { createServer } from 'node:http';
import { toNodeHandler } from '@modelcontextprotocol/node';
import { config } from './config.js';
import { mcpHandler } from './server.js';

const nodeHandler = toNodeHandler(mcpHandler);

function sameSecret(actual: string, expected: string): boolean {
  const actualBuffer = Buffer.from(actual, 'utf8');
  const expectedBuffer = Buffer.from(expected, 'utf8');
  return actualBuffer.length === expectedBuffer.length && timingSafeEqual(actualBuffer, expectedBuffer);
}

function authorized(header: string | undefined): boolean {
  if (!header?.startsWith('Bearer ')) return false;
  return sameSecret(header.slice('Bearer '.length), config.mcpApiKey);
}

function hostAllowed(host: string | undefined): boolean {
  if (config.allowedHosts.length === 0) return true;
  return Boolean(host && config.allowedHosts.includes(host.toLowerCase()));
}

function originAllowed(origin: string | undefined): boolean {
  // Server-to-server MCP clients normally send no Origin header.
  if (!origin) return true;
  if (config.allowedOrigins.length === 0) return false;
  return config.allowedOrigins.includes(origin.toLowerCase());
}

const server = createServer((req, res) => {
  if (req.url === '/health' && req.method === 'GET') {
    res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    res.end(JSON.stringify({ ok: true }));
    return;
  }

  if (req.url !== '/mcp') {
    res.writeHead(404, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    res.end(JSON.stringify({ error: 'not_found' }));
    return;
  }

  if (!hostAllowed(req.headers.host)) {
    res.writeHead(403, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    res.end(JSON.stringify({ error: 'invalid_host' }));
    return;
  }

  if (!originAllowed(req.headers.origin)) {
    res.writeHead(403, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    res.end(JSON.stringify({ error: 'invalid_origin' }));
    return;
  }

  if (!authorized(req.headers.authorization)) {
    res.writeHead(401, {
      'content-type': 'application/json',
      'cache-control': 'no-store',
      'www-authenticate': 'Bearer realm="register-mcp"'
    });
    res.end(JSON.stringify({ error: 'unauthorized' }));
    return;
  }

  void Promise.resolve(nodeHandler(req, res)).catch(error => {
    console.error(`[http] ${error instanceof Error ? error.message : 'Unhandled MCP HTTP error'}`);
    if (!res.headersSent) {
      res.writeHead(500, { 'content-type': 'application/json', 'cache-control': 'no-store' });
      res.end(JSON.stringify({ error: 'internal_server_error' }));
    } else {
      res.destroy();
    }
  });
});

server.requestTimeout = 20_000;
server.headersTimeout = 10_000;
server.keepAliveTimeout = 5_000;

server.listen(config.port, config.host, () => {
  console.log(`register-mcp listening on ${config.host}:${config.port}`);
});

let shuttingDown = false;
async function shutdown(): Promise<void> {
  if (shuttingDown) return;
  shuttingDown = true;

  const forceExit = setTimeout(() => process.exit(1), 5_000);
  forceExit.unref();

  await Promise.allSettled([
    new Promise<void>(resolve => server.close(() => resolve())),
    mcpHandler.close()
  ]);
  process.exit(0);
}

process.on('SIGTERM', () => void shutdown());
process.on('SIGINT', () => void shutdown());
