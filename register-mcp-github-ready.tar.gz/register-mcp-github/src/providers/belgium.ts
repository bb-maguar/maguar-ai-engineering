import { config } from '../config.js';
import type { CompanyRegisterProvider, CompanyRegisterResult, RegisterActivity, RegisterAddress } from './types.js';

type UnknownRecord = Record<string, unknown>;

function asRecord(value: unknown): UnknownRecord | null {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? (value as UnknownRecord)
    : null;
}

function asString(value: unknown): string | null {
  return typeof value === 'string' && value.trim() ? value.trim() : null;
}

export function normalizeBelgianCompanyNumber(input: string): string {
  const normalized = input
    .trim()
    .toUpperCase()
    .replace(/^BE/, '')
    .replace(/[.\s-]/g, '');

  if (!/^\d{10}$/.test(normalized)) {
    throw new Error('Belgian company register ID must contain exactly 10 digits.');
  }

  const base = Number(normalized.slice(0, 8));
  const check = Number(normalized.slice(8));
  const expected = 97 - (base % 97);
  if (check !== expected) {
    throw new Error('Belgian company register ID has an invalid checksum.');
  }

  return normalized;
}

function extractCompany(payload: unknown): UnknownRecord {
  const root = asRecord(payload);
  if (!root) throw new Error('CBE API returned an unexpected response.');

  if (Array.isArray(root.data)) {
    const first = asRecord(root.data[0]);
    if (!first) throw new Error('Company not found in CBE.');
    return first;
  }

  const nested = asRecord(root.data);
  return nested ?? root;
}

function mapAddress(company: UnknownRecord): RegisterAddress | null {
  const address = asRecord(company.address);
  if (!address) return null;

  return {
    street: asString(address.street),
    street_number: asString(address.street_number),
    postal_code: asString(address.post_code ?? address.postal_code),
    city: asString(address.city),
    country_code: asString(address.country_code)
  };
}

function mapActivities(company: UnknownRecord): RegisterActivity[] {
  const raw = Array.isArray(company.nace_activities) ? company.nace_activities : [];
  return raw
    .map(asRecord)
    .filter((item): item is UnknownRecord => item !== null)
    .map(item => ({
      code: asString(item.code) ?? '',
      description: asString(item.description),
      classification: asString(item.classification)
    }))
    .filter(item => item.code.length > 0)
    .slice(0, 10);
}

export class BelgiumRegisterProvider implements CompanyRegisterProvider {
  async lookup(input: string): Promise<CompanyRegisterResult> {
    const companyRegisterId = normalizeBelgianCompanyNumber(input);
    const url = `${config.cbeBaseUrl}/v1/company/${encodeURIComponent(companyRegisterId)}?lang=en`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10_000);

    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${config.cbeApiKey}`,
          Accept: 'application/json',
          'Accept-Language': 'en',
          'User-Agent': 'register-mcp/0.1.0'
        },
        signal: controller.signal
      });

      if (response.status === 404) throw new Error('Company not found in CBE.');
      if (response.status === 401 || response.status === 403) {
        throw new Error('CBE API authentication failed.');
      }
      if (response.status === 429) throw new Error('CBE API rate limit reached.');
      if (!response.ok) throw new Error(`CBE API request failed with HTTP ${response.status}.`);

      const company = extractCompany(await response.json());
      const contacts = asRecord(company.contact_infos);

      return {
        country: 'BE',
        register: 'CBE/KBO/BCE',
        company_register_id: asString(company.cbe_number) ?? companyRegisterId,
        company_register_id_formatted: asString(company.cbe_number_formatted),
        name: asString(company.denomination),
        status: asString(company.status),
        legal_form: asString(company.juridical_form),
        legal_situation: asString(company.juridical_situation),
        registered_address: mapAddress(company),
        website: contacts ? asString(contacts.web) : null,
        activities: mapActivities(company),
        source: 'CBEAPI / Belgian Crossroads Bank for Enterprises'
      };
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        throw new Error('CBE API request timed out.');
      }
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }
}
