export type RegisterAddress = {
  street: string | null;
  street_number: string | null;
  postal_code: string | null;
  city: string | null;
  country_code: string | null;
};

export type RegisterActivity = {
  code: string;
  description: string | null;
  classification: string | null;
};

export type CompanyRegisterResult = {
  country: string;
  register: string;
  company_register_id: string;
  company_register_id_formatted: string | null;
  name: string | null;
  status: string | null;
  legal_form: string | null;
  legal_situation: string | null;
  registered_address: RegisterAddress | null;
  website: string | null;
  activities: RegisterActivity[];
  source: string;
};

export interface CompanyRegisterProvider {
  lookup(companyRegisterId: string): Promise<CompanyRegisterResult>;
}
